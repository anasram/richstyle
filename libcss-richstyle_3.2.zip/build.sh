#!/bin/bash
debuild -us -uc
