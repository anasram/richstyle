
# What is RichStyle?

RichStyle is an HTML5/CSS3 framework for markdown, ePub, and clean HTML files.

As a Debian package, it adds a template file called `Markdown.md` to your file manager
(Dolphin/Nautilus/Caja/Nemo…), to help you:

* create a markdown file with basic YAML metadata fields,
* and view it as a styled HTML file in any web browser.

It enhances your experience with Markdown and ePub software,
like Pandoc, ReText, Formiko, Zim, and Sigil.

## Features

* Meets middle eastern language requirements (RTL direction).
* Complies the Unicode 10.0+ standard for icon addressing (code points).
* Ready for client-side fine printing.

## Compatiblility

* Chromium/Chrome 69
* Firefox 68

## Known Issues

See: [TODO](debian/TODO) file.

## Home Page

[https://richstyle.org](https://richstyle.org)
