## When to Use `book` Class



## How to Support `poetry` Class in Chrome/Chromium

To see poetries correctly, your browser should support `text-align-last` attribute.
Unfortunately this attribute is supported only in Firefox.
But you can activate it in Google Chrome too from
‘chrome://flags/ ⮚ Enable experimental Web Platform features’.
