---
title: RichStyle Demo
lang: en
date: 2021-03-05
---

## Heading 2

### Heading 3

#### Heading 4

##### Heading 5

Paragraph: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

[فقرة: أبجد هوز حطي كلمن سعفص قرشت ثخذ ضظغ.]{lang="ar"}

## Phrasing Elements 

* I must say I _adore_ lemonade.
* This tea is **very hot**.
* Check [RichStyle homepage](https://richstyle.org/)
* The judge said: "You can drink water from the fish tank" but advised against it.
* The `fruitdb` program can be used for tracking fruit production.
* Elderflower cordial, with one [part]{.mark} cordial to ten [part]{.mark}s water, stands a[part]{.mark} from the rest.
* His name in Arabic is [محمد]{lang="ar"}.
* 2^10^ is 1024.
* Water is H~2~O.
* Price is ~~\$200~~ \$150.

---

* The New price is <ins>$150</ins>.
* These grapes are made into wine. <small>Alcohol is addictive</small>.
* Published at: <time>2009-10-21 12:05</time>.
* <abbr title="HyperText Markup Language">HTML</abbr> is maintained by <abbr title="World Wide Web Consortium">W3C</abbr>.
* Press <kbd>F1</kbd> for help.

<!--

* The New price is [\$150]{.ins}.
* These grapes are made into wine. [Alcohol is addictive]{.small}.
* Published at: [2009-10-21 12:05]{.time}.
* [HTML]("HyperText Markup Language"){.abbr} is maintained by [W3C]("World Wide Web Consortium"){.abbr}.
* Press [F1]{kbd} for help.

-->

## Multimedia

![](/usr/share/icons/hicolor/scalable/apps/richstyle.svg "Title: RichStyle logo")

![Caption: RichStyle logo](/usr/share/icons/hicolor/scalable/apps/richstyle.svg "Title: RichStyle logo")

![Caption: Unknown Video](unkown.ogv "Title: Unknown Video")

## Block Elements

> Blockquote: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

Here’s a preformatted text:

```
begin preformatted text     preformatted text preformatted text preformatted text preformatted text end
begin preformatted text     preformatted text preformatted text preformatted text preformatted text end
```

Here’s another preformatted text:

```
begin preformatted text     preformatted text end
begin preformatted text     preformatted text end
```

[Rule: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.]{.msg-rule}

## States

[Information: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.]{.msg-info}

[Tip: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.]{.msg-tip}

[Note: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.]{.msg-note}

[Warning: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.]{.msg-warning}

[Under Construction: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.]{.msg-under-construction}

[Question: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.]{.msg-question}

[Credits: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.]{.msg-credits}

[Error: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.]{.msg-error}

[Invalid: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.]{.msg-invalid}

[Loading: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.]{.msg-busy}

[Succeeded: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.]{.msg-succeeded}

[Update: Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.]{.msg-update}

## Ordered List

1. Lorem ipsum dolor sit amet, consectetur `adipiscing` elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
2. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
3. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.

## Definition List

CSS
:	Cascading Style Sheets

HTML
:	HyperText Markup Language

W3C
:	World Wide Web Consortium

## Tables

<table>
<caption>Regular Table</caption>
<tr>
	<th>Table Header Cell</th>
    <th>Table Header Cell</th>
</tr>
<tr>
	<td>table data cell</td>
	<td>table data cell, table data cell, table data cell</td>
</tr>
<tr>
	<td>table data cell</td>
	<td>table data cell, table data cell, table data cell</td>
</tr>
<tr>
	<td>table data cell</td>
	<td>table data cell, table data cell, table data cell</td>
</tr>
<tr>
	<td>table data cell</td>
	<td>table data cell, table data cell, table data cell</td>
</tr>
</table>

<table class="comparison">
<caption>Comparison Table</caption>
<tr>
	<th>Table Header Cell</th>
    <th>Table Header Cell</th>
</tr>
<tr>
	<td>table data cell</td>
	<td>table data cell, table data cell, table data cell</td>
</tr>
<tr>
	<td>table data cell</td>
	<td>table data cell, table data cell, table data cell</td>
</tr>
<tr>
	<td>table data cell</td>
	<td>table data cell, table data cell, table data cell</td>
</tr>
<tr>
	<td>table data cell</td>
	<td>table data cell, table data cell, table data cell</td>
</tr>
</table>

<table class="fixedTable">
<caption>Fixed Table</caption>
<tr>
	<th>Table Header Cell</th>
    <th>Table Header Cell</th>
</tr>
<tr>
	<td>table data cell</td>
	<td>table data cell, table data cell</td>
</tr>
<tr>
	<td>table data cell</td>
	<td>table data cell, table data cell</td>
</tr>
<tr>
	<td>table data cell</td>
	<td>table data cell, table data cell</td>
</tr>
<tr>
	<td>table data cell</td>
	<td>table data cell, table data cell</td>
</tr>
</table>

## Poetry

<table class="poetry">
<tr>
	<td>O mistress mine, where are you roaming?</td>
	<td>O stay and hear! your true-love’s coming</td>
</tr>
<tr>
	<td colspan="2">That can sing both high and low</td>
</tr>
<tr>
	<td>Trip no further, pretty sweeting</td>
	<td>Journey’s end in lovers’ meeting</td>
</tr>
<tr>
	<td colspan="2">Every wise man’s son doth know</td>
</tr>
<tr>
	<td>What is love? ’tis not hereafter</td>
	<td>Present mirth hath present laughter</td>
</tr>
<tr>
	<td colspan="2">What’s to come is still unsure:</td>
</tr>
<tr>
	<td>In delay there lies no plenty</td>
	<td>Then come kiss me, Sweet and twenty</td>
</tr>
<tr>
	<td colspan="2">Youth’s a stuff will not endure</td>
</tr>
</table>

## Math Equation

<math>
<mi>x</mi>
<mo>=</mo>
<mfrac>
	<mrow>
	<mo form="prefix">−</mo> <mi>b</mi>
	<mo>±</mo>
	<msqrt>
		<msup> <mi>b</mi> <mn>2</mn> </msup>
		<mo>−</mo>
		<mn>4</mn> <mo>⁢</mo> <mi>a</mi> <mo>⁢</mo> <mi>c</mi>
	</msqrt>
	</mrow>
	<mrow>
	<mn>2</mn> <mo>⁢</mo> <mi>a</mi>
	</mrow>
</mfrac>
</math>

