#!/bin/bash
file="doc.md";

cp "$file" "/tmp/"; 
cd "/tmp/";
pandoc -f markdown+hard_line_breaks -t html\
	--template="/usr/share/richstyle/data/templates/richstyle.html"\
	--html-q-tags\
	"$file" -o "$file.html";
rm "$file";
x-www-browser "$file.html";
rm "$file.html";
