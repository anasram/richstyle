#!/bin/bash
file="doc.md";

pandoc -f markdown+hard_line_breaks -t html\
	--template="/usr/share/richstyle/data/templates/richstyle.html"\
	--html-q-tags\
	"$file" | x-www-browser "data:text/html;base64, $(base64 -w 0 <&0)";
